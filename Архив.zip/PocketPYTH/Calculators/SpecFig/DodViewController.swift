//
//  DodViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 20.12.2021.
//

import UIKit

class DodViewController: UIViewController {

    @IBOutlet weak var a: UITextField!
    @IBOutlet weak var result: UILabel!
    
    @IBAction func Res(_ sender: Any) {
        let a = Double(a.text!) ?? 0.0
        let V = (pow(a,3)*(15+7*sqrt(5)))/4
        
        if (V - floor(V) == 0){
            result.text = String(Int(V));
        } else {
            result.text = String(V);
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func GoBack(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is SpecFigViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
