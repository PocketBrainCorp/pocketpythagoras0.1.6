//
//  SquareEqualViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 07.12.2021.
//

import UIKit

class SquareEqualViewController: UIViewController {

    @IBOutlet weak var a: UITextField!
    @IBOutlet weak var b: UITextField!
    @IBOutlet weak var c: UITextField!
    @IBOutlet weak var result1: UILabel!
    @IBOutlet weak var result2: UILabel!
    @IBOutlet weak var result: UILabel!
    
    @IBAction func Res(_ sender: UIButton) {
        let a = Double(a.text!) ?? 0.0
        let b = Double(b.text!) ?? 0.0
        let c = Double(c.text!) ?? 0.0
        
        let d = pow(b,2) - 4*a*c
        
        if d > 0 {
            let x1 = ((-b)+sqrt(d))/(2*a)
            let x2 = ((-b)-sqrt(d))/(2*a)
            //result.text = String("У уравнения два корня")
            if (x1 - floor(x1) == 0){
                result1.text = String(Int(x1))
            } else {
                result1.text = String(x1)
            }
            if (x2 - floor(x2) == 0) {
                result2.text = String(Int(x2))
            } else {
                result2.text = String(x2)
            }
        } else if d == 0 {
            let x1 = ((-b)/(2*a))
            //result.text = String("У уравнения один корень")
            result2.text = String("Второго корня нет")
            if (x1 - floor(x1) == 0) {
                result1.text = String(Int(x1))
            } else {
                result1.text = String(x1)
            }
        } else {
            result1.text = String("Первого корня нет")
            result2.text = String("Второго корня нет")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func GoBack(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is LeftViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
